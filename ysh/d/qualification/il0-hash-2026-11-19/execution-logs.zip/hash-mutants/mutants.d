module mutants;

import std.algorithm : sort;
import std.array : join;
import std.conv : to;
import std.digest : toHexString;
import std.digest.sha : sha256Of;
import std.file : SpanMode, copy, dirEntries, getAttributes, mkdirRecurse, read,
    readText, setAttributes, write;
import std.path : absolutePath, buildPath, dirName, relativePath;
import std.process : execute, spawnProcess, wait;
import std.stdio : File, stderr, writeln;
import std.string : indexOf, toLower;

private string hash(string path) { return sha256Of(read(path)).toHexString.toLower; }
private string hashText(string text) { return sha256Of(text).toHexString.toLower; }

private string[] modules(string source) {
    string[] result;
    foreach (entry; dirEntries(source, SpanMode.depth))
        if (entry.isFile && entry.name.length >= 2 && entry.name[$ - 2 .. $] == ".d") result ~= entry.name;
    sort(result);
    return result;
}

private string sourceManifest(string source) {
    string result;
    foreach (path; modules(source)) result ~= relativePath(path, source) ~ "\t" ~ hash(path) ~ "\n";
    return result;
}

private void copySources(string source, string destination) {
    mkdirRecurse(destination);
    foreach (entry; dirEntries(source, SpanMode.depth)) {
        auto target = buildPath(destination, relativePath(entry.name, source));
        if (entry.isDir) mkdirRecurse(target);
        else { mkdirRecurse(dirName(target)); copy(entry.name, target); }
    }
}

private string replaceOnce(string source, string before, string after) {
    auto at = source.indexOf(before);
    if (at < 0 || source[at + before.length .. $].indexOf(before) >= 0)
        throw new Exception("mutation context is absent or ambiguous");
    return source[0 .. at] ~ after ~ source[at + before.length .. $];
}

private int runLogged(string[] argv, string directory) {
    mkdirRecurse(directory);
    auto input = File("/dev/null", "r");
    auto output = File(buildPath(directory, "stdout"), "w");
    auto errors = File(buildPath(directory, "stderr"), "w");
    write(buildPath(directory, "argv.txt"), argv.join("\n") ~ "\n");
    auto status = wait(spawnProcess(argv, input, output, errors));
    write(buildPath(directory, "status"), to!string(status) ~ "\n");
    return status;
}

private struct Mutation {
    string name;
    string modulePath;
    string before;
    string after;
    string probe;
}

private string[] compilerArguments(string compiler, string toolchain, string root, string source, string binary) {
    auto phobos = buildPath(toolchain, "phobos");
    auto result = [compiler, "-conf=", "-fPIC", "-w", "-I" ~ source,
        "-J" ~ buildPath(root, "stdlib"), "-J" ~ root,
        "-I" ~ buildPath(toolchain, "runtime-dmd/druntime/import"), "-I" ~ phobos,
        buildPath(phobos, "generated/linux/release/64/libphobos2.a"),
        "-defaultlib=", "-debuglib=", "-L-lpthread", "-L-lm", "-L-ldl",
        "-L-Map=" ~ binary ~ ".map"];
    result ~= modules(source);
    result ~= "-of=" ~ binary;
    return result;
}

private void fixture(string source, string target, ref string manifest) {
    mkdirRecurse(dirName(target));
    copy(source, target);
    auto mode = getAttributes(source);
    setAttributes(target, mode);
    manifest ~= target ~ "\t" ~ source ~ "\t" ~ hash(source) ~ "\t" ~ hash(target) ~ "\t" ~ to!string(mode) ~ "\n";
}

private void curate(string output, string lean, Mutation[] mutations) {
    mkdirRecurse(lean);
    foreach (name; ["mutants.d", "receipt.tsv", "baseline-identity.tsv", "baseline-source.tsv", "fixture-manifest.tsv"])
        copy(buildPath(output, name), buildPath(lean, name));
    foreach (mutation; mutations) {
        auto original = buildPath(output, mutation.name);
        auto target = buildPath(lean, mutation.name);
        mkdirRecurse(target);
        foreach (name; ["mutation.patch", "source.tsv", "expectations.grease"])
            copy(buildPath(original, name), buildPath(target, name));
        foreach (stage; ["compile", "baseline", "runtime"]) {
            mkdirRecurse(buildPath(target, stage));
            foreach (name; ["argv.txt", "stdout", "stderr", "status"])
                copy(buildPath(original, stage, name), buildPath(target, stage, name));
        }
    }
}

int main(string[] arguments) {
    if (arguments.length != 6) {
        stderr.writeln("mutants ROOT FINAL_BINARY OUTPUT TOOLCHAIN LEAN_EVIDENCE");
        return 2;
    }
    auto root = absolutePath(arguments[1]);
    auto baselineBinary = absolutePath(arguments[2]);
    auto output = absolutePath(arguments[3]);
    auto toolchain = absolutePath(arguments[4]);
    auto lean = absolutePath(arguments[5]);
    auto compiler = buildPath(toolchain, "runtime-dmd/generated/linux/release/64/dmd");
    auto source = buildPath(root, "ysh/d/source");
    mkdirRecurse(output);
    auto snapshot = sourceManifest(source);
    auto baselineHash = hash(baselineBinary);
    write(buildPath(output, "baseline-source.tsv"), snapshot);
    write(buildPath(output, "baseline-identity.tsv"),
        "kind\tpath\tsha256\ncompiler\t" ~ compiler ~ "\t" ~ hash(compiler) ~
        "\nphobos\t" ~ buildPath(toolchain, "phobos/generated/linux/release/64/libphobos2.a") ~ "\t" ~
        hash(buildPath(toolchain, "phobos/generated/linux/release/64/libphobos2.a")) ~
        "\nbaseline_binary\t" ~ baselineBinary ~ "\t" ~ baselineHash ~
        "\nbaseline_source\t" ~ source ~ "\t" ~ hashText(snapshot) ~ "\n");

    auto first = buildPath(output, "fixtures/first");
    auto second = buildPath(output, "fixtures/second");
    string fixtures = "target\tsource\tsource_sha256\ttarget_sha256\tmode\n";
    fixture("/usr/bin/true", buildPath(first, "hash-cache-probe"), fixtures);
    fixture("/usr/bin/false", buildPath(second, "hash-cache-probe"), fixtures);
    fixture("/usr/bin/false", buildPath(first, "hash-reset-probe"), fixtures);
    fixture("/usr/bin/true", buildPath(second, "hash-reset-probe"), fixtures);
    fixture("/usr/bin/false", buildPath(first, "uname"), fixtures);
    write(buildPath(output, "fixture-manifest.tsv"), fixtures);

    enum externalLookup = "    auto path = useDefaultPath ? lookupExecutable(argv[0], defaultCommandPath.split(\":\")) :\n        mem.searchPath.cachedLookup(argv[0]);";
    Mutation[] mutations = [
        Mutation("ignore-existing-cache", "yshd/command_lookup.d",
            "    string cachedLookup(string name) {\n        if (auto found = name in cache) return *found;",
            "    string cachedLookup(string name) {\n        // Fault: ignore an already retained command path.",
            `set -eu -o pipefail
var first = ARGV[0]
var second = ARGV[1]
setglobal ENV.PATH = first
hash hash-cache-probe
setglobal ENV.PATH = second
hash-cache-probe
echo 'PASS ignore-existing-cache'
`),
        Mutation("skip-ordinary-command-population", "yshd/process.d", externalLookup,
            "    auto path = useDefaultPath ? lookupExecutable(argv[0], defaultCommandPath.split(\":\")) :\n        mem.searchPath.lookupOne(argv[0]);",
            `set -eu -o pipefail
var first = ARGV[0]
var second = ARGV[1]
setglobal ENV.PATH = first
hash-cache-probe
setglobal ENV.PATH = second
hash-cache-probe
echo 'PASS skip-ordinary-command-population'
`),
        Mutation("retain-cache-after-reset", "yshd/command_lookup.d",
            "    void clearCache() { cache = null; }",
            "    void clearCache() { /* Fault: retain all old paths. */ }",
            `set -eu -o pipefail
var first = ARGV[0]
var second = ARGV[1]
setglobal ENV.PATH = first
hash hash-reset-probe
setglobal ENV.PATH = second
hash -r
var entries = $(hash)
test -z "$entries"
hash-reset-probe
echo 'PASS retain-cache-after-reset'
`),
        Mutation("default-path-uses-cache", "yshd/process.d", externalLookup,
            "    auto path = mem.searchPath.cachedLookup(argv[0]);",
            `set -eu -o pipefail
var first = ARGV[0]
setglobal ENV.PATH = first
hash uname
command -p uname >/dev/null
var entries = $(hash)
test "$entries" = "$first/uname"
echo 'PASS default-path-uses-cache'
`)
    ];

    string receipt = "control\tmutated_module\tcompile_status\tbaseline_status\tmutant_status\tbaseline_source_sha256\tmutant_source_sha256\tpatch_sha256\tprobe_sha256\tbinary_sha256\tresult\n";
    write(buildPath(output, "receipt.tsv"), receipt);
    foreach (mutation; mutations) {
        auto directory = buildPath(output, mutation.name);
        auto copySource = buildPath(directory, "source");
        copySources(source, copySource);
        auto originalPath = buildPath(source, mutation.modulePath);
        auto changedPath = buildPath(copySource, mutation.modulePath);
        write(changedPath, replaceOnce(readText(originalPath), mutation.before, mutation.after));
        auto manifest = sourceManifest(copySource);
        write(buildPath(directory, "source.tsv"), manifest);
        auto diff = execute(["/usr/bin/diff", "-u", originalPath, changedPath]);
        if (diff.status != 1) throw new Exception("mutation did not produce an exact diff");
        auto patch = buildPath(directory, "mutation.patch");
        write(patch, diff.output);
        auto probe = buildPath(directory, "expectations.grease");
        write(probe, mutation.probe);
        auto baselineStatus = runLogged([baselineBinary, probe, first, second], buildPath(directory, "baseline"));
        auto expected = "PASS " ~ mutation.name ~ "\n";
        if (baselineStatus != 0 || readText(buildPath(directory, "baseline/stdout")) != expected ||
                readText(buildPath(directory, "baseline/stderr")) != "")
            throw new Exception("final candidate did not pass " ~ mutation.name);
        auto binary = buildPath(directory, "ysh-d-mutant");
        auto compileStatus = runLogged(compilerArguments(compiler, toolchain, root, copySource, binary),
            buildPath(directory, "compile"));
        if (compileStatus != 0) throw new Exception("mutant did not compile: " ~ mutation.name);
        auto mutantStatus = runLogged([binary, probe, first, second], buildPath(directory, "runtime"));
        auto caught = mutantStatus == 1 && readText(buildPath(directory, "runtime/stdout")) != expected;
        receipt ~= mutation.name ~ "\t" ~ mutation.modulePath ~ "\t" ~ to!string(compileStatus) ~
            "\t" ~ to!string(baselineStatus) ~ "\t" ~ to!string(mutantStatus) ~ "\t" ~ hashText(snapshot) ~
            "\t" ~ hashText(manifest) ~ "\t" ~ hash(patch) ~ "\t" ~ hash(probe) ~ "\t" ~ hash(binary) ~
            "\t" ~ (caught ? "PASS" : "FAIL") ~ "\n";
        write(buildPath(output, "receipt.tsv"), receipt);
        if (!caught) throw new Exception("expectations accepted mutant " ~ mutation.name);
        writeln("PASS ", mutation.name, " compile=0 baseline=0 mutant=1");
    }
    if (sourceManifest(source) != snapshot || hash(baselineBinary) != baselineHash)
        throw new Exception("live source or final candidate changed during controls");
    curate(output, lean, mutations);
    return 0;
}
