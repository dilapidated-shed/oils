set -euxo pipefail
ysh/d/.build/ysh-d-unittests
actual=$(ysh/d/.build/ysh-d '1 + 2 * 3')
test "$actual" = 7
ysh/d/.build/ysh-d -c 'var x = 1; setvar x = 42'
actual=$(ysh/d/.build/ysh-d -c "var items = ['a b', 'c d']; var answer = 42; write @items; write \$answer \$[6 * 7] @[['x', 'y']]; echo s=\$answer; echo \"value=\$answer\"; write pre\$answer-post; for i, item in red green blue { echo \"\$i:\$item\" }; echo hello world; echo -n joined; write one two; write --sep '_' --end ' END' -- alpha beta; write -n x; write y")
expected=$(printf 'a b\nc d\n42\n42\nx\ny\ns=42\nvalue=42\npre42-post\n0:red\n1:green\n2:blue\nhello world\njoinedone\ntwo\nalpha_beta ENDxy\n')
test "$actual" = "$expected"

actual=$(ysh/d/.build/ysh-d -c "write --json u'\\u{3bc}' x; write --j8 b'\\yfe\\yff' y")
expected=$(printf '"μ"\n"x"\nb'\''\\yfe\\yff'\''\n"y"\n')
test "$actual" = "$expected"

actual=$(ysh/d/.build/ysh-d -c "echo -en 'abc\\ndef\\n'; echo -e xy 'ab\\cde' zzz")
expected=$(printf 'abc\ndef\nxy ab')
test "$actual" = "$expected"

actual=$(ysh/d/.build/ysh-d -c "shopt -s ysh:upgrade; printf '<%s>\\n' alpha beta")
expected=$(printf '<alpha>\n<beta>\n')
test "$actual" = "$expected"

actual=$(ysh/d/.build/ysh-d -c "setglobal ENV.YSH_D_PROBE = 'from-d'; sh -c 'printf \"%s\\n\" \"\$YSH_D_PROBE\"'")
expected=$(printf 'from-d\n')
test "$actual" = "$expected"

actual=$(ysh/d/.build/ysh-d -c "printf 'one\\ntwo\\n' | grep two")
expected=$(printf 'two\n')
test "$actual" = "$expected"

actual=$(ysh/d/.build/ysh-d -c "write alpha beta | grep beta; printf 'left\\nright\\n' | read --all; echo captured=\$[_reply]")
expected=$(printf 'beta\ncaptured=left\nright\n\n')
test "$actual" = "$expected"

actual=$(ysh/d/.build/ysh-d -c "AA=temporary sh -c 'printf \"%s\\n\" \"\$AA\"'; proc show_env { sh -c 'printf \"%s\\n\" \"\$BB\"' }; BB=inside-proc show_env")
expected=$(printf 'temporary\ninside-proc\n')
test "$actual" = "$expected"

actual=$(ysh/d/.build/ysh-d -c "eval 'echo evaluated'; :")
expected=$(printf 'evaluated\n')
test "$actual" = "$expected"

printf 'echo sourced\n' > "$RUNNER_TEMP/ysh-d-source.ysh"
actual=$(ysh/d/.build/ysh-d -c "source '$RUNNER_TEMP/ysh-d-source.ysh'")
expected=$(printf 'sourced\n')
test "$actual" = "$expected"

set +e
ysh/d/.build/ysh-d -c 'exit 23'
status=$?
set -e
test "$status" = 23

actual=$(printf 'echo stdin-mode\n' | ysh/d/.build/ysh-d)
expected=$(printf 'stdin-mode\n')
test "$actual" = "$expected"

actual=$(ysh/d/.build/ysh-d -c "read --all <<< 'here value'; echo \"\$[_reply]\"")
expected=$(printf 'here value\n')
test "$actual" = "$expected"

actual=$(ysh/d/.build/ysh-d +e -c "sh -c 'exit 7'; echo status=\$?")
expected=$(printf 'status=7\n')
test "$actual" = "$expected"

actual=$(ysh/d/.build/ysh-d -c "echo value=\$(printf captured); write -- @(seq 3)")
expected=$(printf 'value=captured\n1\n2\n3\n')
test "$actual" = "$expected"

actual=$(ysh/d/.build/ysh-d -c "var a = [1, 2, 3]; var d = {key: 42}; echo len=\$[len(a)] abs=\$[abs(-3)] max=\$[max(3, 9, 4)]; echo \"key \$[d[\"key\"]]\"; var strings = @[a]; write -- @strings")
expected=$(printf 'len=3 abs=3 max=9\nkey 42\n1\n2\n3\n')
test "$actual" = "$expected"

# First D-native Grease alias slice: no Python/C++ shell executes.
actual=$(ysh/d/.build/ysh-d -c "shopt -s ysh:all
alias ll='echo alias-ok'
ll
unalias ll
if alias ll { echo wrong } else { echo status=\$? }")
expected=$(printf 'alias-ok\nstatus=1\n')
test "$actual" = "$expected"

redirect_file="$RUNNER_TEMP/ysh-d-redirect.txt"
actual=$(ysh/d/.build/ysh-d -c "echo first > '$redirect_file'; echo second >> '$redirect_file'; cat < '$redirect_file'; if (true) { echo block } > '$redirect_file'; cat '$redirect_file'")
expected=$(printf 'first\nsecond\nblock\n')
test "$actual" = "$expected"

actual=$(ysh/d/.build/ysh-d +e -c "x=assigned; echo x=\$x; true; echo true=\$?; false; echo false=\$?; assert [1 + 1 === 2]")
expected=$(printf 'x=assigned\ntrue=0\nfalse=1\n')
test "$actual" = "$expected"

actual=$(ysh/d/.build/ysh-d -c "var items = list(1..<4); call items->append(4); call items->insert(-1, 9); echo list=\$[items => join(',')]; var d = {a: 2}; call d->inc('a', 3); call d->append('seen', 7); echo keys=\$[d => keys() => join('/')]; echo starts=\$['abc' => startsWith('a')] trim=\$['xxabcxx' => trim('xx')] upper=\$['ab' => upper()]")
expected=$(printf 'list=1,2,3,9,4\nkeys=a/seen\nstarts=true trim=abc upper=AB\n')
test "$actual" = "$expected"

actual=$(ysh/d/.build/ysh-d -c "var d = {a: 1, b: [2, 3]}; json write (d, space=0); pp test_ (d)")
expected=$(printf '{"a":1,"b":[2,3]}\n(Dict)   {"a":1,"b":[2,3]}\n')
test "$actual" = "$expected"

read_file="$RUNNER_TEMP/ysh-d-read.txt"
printf 'alpha\nbeta\n' > "$read_file"
actual=$(ysh/d/.build/ysh-d -c "read --all < '$read_file'; echo all=\$[_reply]; read --line < '$read_file'; echo line=\$[_reply]")
expected=$(printf 'all=alpha\nbeta\n\nline=alpha\n')
test "$actual" = "$expected"
