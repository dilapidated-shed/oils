module mutants;

import std.algorithm : sort;
import std.array : join;
import std.conv : to;
import std.digest : toHexString;
import std.digest.sha : sha256Of;
import std.file : SpanMode, copy, dirEntries, mkdirRecurse, read, readText, write;
import std.path : absolutePath, baseName, buildPath, dirName, relativePath;
import std.process : environment, execute, spawnProcess, wait;
import std.stdio : File, stderr, writeln;
import std.string : indexOf, toLower;

private string hash(string path) { return sha256Of(read(path)).toHexString.toLower; }
private string hashText(string text) { return sha256Of(text).toHexString.toLower; }

private string[] modules(string source) {
    string[] result;
    foreach (entry; dirEntries(source, SpanMode.depth))
        if (entry.isFile && entry.name.length >= 2 && entry.name[$ - 2 .. $] == ".d") result ~= entry.name;
    sort(result);
    return result;
}

private string sourceManifest(string source) {
    string result;
    foreach (path; modules(source)) result ~= relativePath(path, source) ~ "\t" ~ hash(path) ~ "\n";
    return result;
}

private void copySources(string source, string destination) {
    mkdirRecurse(destination);
    foreach (entry; dirEntries(source, SpanMode.depth)) {
        auto target = buildPath(destination, relativePath(entry.name, source));
        if (entry.isDir) mkdirRecurse(target);
        else { mkdirRecurse(dirName(target)); copy(entry.name, target); }
    }
}

private string replaceOnce(string source, string before, string after) {
    auto at = source.indexOf(before);
    if (at < 0 || source[at + before.length .. $].indexOf(before) >= 0)
        throw new Exception("mutation context is absent or ambiguous");
    return source[0 .. at] ~ after ~ source[at + before.length .. $];
}

private int runLogged(string[] argv, string directory, string resourceRoot = "", bool controlledResources = false) {
    mkdirRecurse(directory);
    auto input = File("/dev/null", "r");
    auto output = File(buildPath(directory, "stdout"), "w");
    auto errors = File(buildPath(directory, "stderr"), "w");
    write(buildPath(directory, "argv.txt"), argv.join("\n") ~ "\n");
    string[string] childEnvironment;
    if (controlledResources) {
        childEnvironment = environment.toAA();
        childEnvironment.remove("_OVM_IS_BUNDLE");
        childEnvironment.remove("_OVM_PATH");
        childEnvironment.remove("_OVM_RESOURCE_ROOT");
        if (resourceRoot.length) childEnvironment["_OVM_RESOURCE_ROOT"] = resourceRoot;
        write(buildPath(directory, "resource-environment.tsv"),
            "name\tvalue\n_OVM_IS_BUNDLE\t<unset>\n_OVM_PATH\t<unset>\n_OVM_RESOURCE_ROOT\t" ~
            (resourceRoot.length ? resourceRoot : "<unset>") ~ "\n");
    } else write(buildPath(directory, "resource-environment.tsv"), "compiler inherited environment\n");
    auto status = wait(spawnProcess(argv, input, output, errors, childEnvironment));
    write(buildPath(directory, "status"), to!string(status) ~ "\n");
    return status;
}

private struct Mutation {
    string name;
    string before;
    string after;
    string topic;
    string expected;
    bool customVersion;
}

private string[] compilerArguments(string compiler, string toolchain, string root, string source, string binary) {
    auto phobos = buildPath(toolchain, "phobos");
    auto result = [compiler, "-conf=", "-fPIC", "-w", "-I" ~ source,
        "-J" ~ buildPath(root, "stdlib"), "-J" ~ root,
        "-I" ~ buildPath(toolchain, "runtime-dmd/druntime/import"), "-I" ~ phobos,
        buildPath(phobos, "generated/linux/release/64/libphobos2.a"),
        "-defaultlib=", "-debuglib=", "-L-lpthread", "-L-lm", "-L-ldl",
        "-L-Map=" ~ binary ~ ".map"];
    result ~= modules(source);
    result ~= "-of=" ~ binary;
    return result;
}

private string probe(Mutation mutation) {
    auto result = "set -eu -o pipefail\nvar expectedFile = ARGV[0]\n";
    if (mutation.customVersion)
        result ~= "var resourceRoot = ARGV[1]\nprintf '%s\\n' '99.88.77-help-changed-cache' > \"$resourceRoot/oils-version.txt\"\n";
    result ~= "var expected = io.captureAll(^(cat $expectedFile))\n" ~
        "test \"$[expected.status]\" = 0\n" ~
        "var actual = io.captureAll(^(help " ~ mutation.topic ~ "))\n" ~
        "test \"$[actual.status]\" = 0\n" ~
        "test \"$[actual.stderr]\" = ''\n" ~
        "test \"$[actual.stdout]\" = \"$[expected.stdout]\"\n" ~
        "echo 'PASS " ~ mutation.name ~ "'\n";
    return result;
}

private void curate(string output, string lean, Mutation[] mutations) {
    mkdirRecurse(lean);
    foreach (name; ["mutants.d", "receipt.tsv", "baseline-identity.tsv", "baseline-source.tsv",
            "resource-inputs.tsv", "git-identity.tsv", "custom-initial-version.txt", "custom-changed-version.txt"])
        copy(buildPath(output, name), buildPath(lean, name));
    foreach (mutation; mutations) {
        auto original = buildPath(output, mutation.name);
        auto target = buildPath(lean, mutation.name);
        mkdirRecurse(target);
        foreach (name; ["mutation.patch", "source.tsv", "expectations.grease", "expected.stdout"])
            copy(buildPath(original, name), buildPath(target, name));
        foreach (stage; ["compile", "baseline", "runtime"]) {
            mkdirRecurse(buildPath(target, stage));
            foreach (name; ["argv.txt", "stdout", "stderr", "status", "resource-environment.tsv"])
                copy(buildPath(original, stage, name), buildPath(target, stage, name));
        }
    }
}

int main(string[] arguments) {
    if (arguments.length != 6) {
        stderr.writeln("mutants ROOT FINAL_BINARY OUTPUT TOOLCHAIN LEAN_EVIDENCE");
        return 2;
    }
    auto root = absolutePath(arguments[1]);
    auto baselineBinary = absolutePath(arguments[2]);
    auto output = absolutePath(arguments[3]);
    auto toolchain = absolutePath(arguments[4]);
    auto lean = absolutePath(arguments[5]);
    auto compiler = buildPath(toolchain, "runtime-dmd/generated/linux/release/64/dmd");
    auto source = buildPath(root, "ysh/d/source");
    auto originalPath = buildPath(source, "yshd/help.d");
    auto original = readText(originalPath);
    auto resources = buildPath(root, "ysh/d/resources/help");
    mkdirRecurse(output);
    auto snapshot = sourceManifest(source);
    auto baselineHash = hash(baselineBinary);
    write(buildPath(output, "baseline-source.tsv"), snapshot);
    write(buildPath(output, "baseline-identity.tsv"),
        "kind\tpath\tsha256\ncompiler\t" ~ compiler ~ "\t" ~ hash(compiler) ~
        "\nphobos\t" ~ buildPath(toolchain, "phobos/generated/linux/release/64/libphobos2.a") ~ "\t" ~
        hash(buildPath(toolchain, "phobos/generated/linux/release/64/libphobos2.a")) ~
        "\nbaseline_binary\t" ~ baselineBinary ~ "\t" ~ baselineHash ~
        "\nbaseline_source\t" ~ source ~ "\t" ~ hashText(snapshot) ~
        "\ncanonical_inputs\t" ~ buildPath(resources, "canonical-inputs.sha256") ~ "\t" ~
        hash(buildPath(resources, "canonical-inputs.sha256")) ~ "\n");
    string gitIdentity;
    foreach (item; ["HEAD", "HEAD^{tree}", "HEAD:ysh/d/source"]) {
        auto value = execute(["/usr/bin/git", "-C", root, "rev-parse", item]);
        if (value.status != 0) throw new Exception("cannot identify committed source");
        gitIdentity ~= item ~ "\t" ~ value.output;
    }
    write(buildPath(output, "git-identity.tsv"), gitIdentity);

    auto fileRoot = buildPath(output, "fixtures/file-root");
    auto helpRoot = buildPath(fileRoot, "_devbuild/help");
    mkdirRecurse(helpRoot);
    string resourceManifest = "canonical_source\tsource_sha256\tfixture_path\tfixture_sha256\n";
    string[] cards;
    foreach (entry; dirEntries(buildPath(resources, "cards"), SpanMode.shallow))
        if (entry.isFile) cards ~= entry.name;
    sort(cards);
    if (cards.length != 34) throw new Exception("expected all 34 canonical resource cards");
    foreach (card; cards) {
        auto target = buildPath(helpRoot, baseName(card));
        copy(card, target);
        resourceManifest ~= card ~ "\t" ~ hash(card) ~ "\t" ~ target ~ "\t" ~ hash(target) ~ "\n";
    }
    foreach (name; ["oils-version.txt", "topics.pylit"]) {
        auto path = buildPath(resources, name);
        resourceManifest ~= path ~ "\t" ~ hash(path) ~ "\t<canonical provenance only>\t-\n";
    }
    auto grammar = buildPath(dirName(root), "oils-help-reference-full/_devbuild/gen/grammar.marshal");
    auto grammarTarget = buildPath(fileRoot, "_devbuild/gen/grammar.marshal");
    mkdirRecurse(dirName(grammarTarget));
    copy(grammar, grammarTarget);
    resourceManifest ~= grammar ~ "\t" ~ hash(grammar) ~ "\t" ~ grammarTarget ~ "\t" ~ hash(grammarTarget) ~ "\n";
    write(buildPath(output, "resource-inputs.tsv"), resourceManifest);
    enum initialVersion = "99.88.77-help-startup-cache\nignored-version-line\n";
    enum changedVersion = "99.88.77-help-changed-cache\n";
    write(buildPath(output, "custom-initial-version.txt"), initialVersion);
    write(buildPath(output, "custom-changed-version.txt"), changedVersion);
    auto sourceVersion = readText(buildPath(resources, "oils-version.txt"));
    auto versionEnd = sourceVersion.indexOf('\n');
    if (versionEnd >= 0) sourceVersion = sourceVersion[0 .. versionEnd];
    auto topicUrl = "~~~ read ~~~\n\n    https://oils.pub/release/" ~ sourceVersion ~ "/doc/ref/chap-builtin-cmd.html#read\n\n";
    Mutation[] mutations = [
        Mutation("ignore-url-metadata",
            "        auto chapter = topic in metadata;",
            "        auto chapter = \"absent-metadata-control-key\" in metadata;",
            "read", topicUrl),
        Mutation("case-sensitive-error-prefix",
            "        auto lower = asciiLower(topic);",
            "        auto lower = topic;",
            "OiLs-ErR-XYz", "\n    https://oils.pub/release/" ~ sourceVersion ~ "/doc/error-catalog.html#oils-err-xyz\n\n"),
        Mutation("omit-embedded-card-contents",
            "    printTopicHeader(topic, output);\n    output.write(contents);\n    output.write(\"\\n\");",
            "    printTopicHeader(topic, output);\n    output.write(\"\");\n    output.write(\"\\n\");",
            "help", "~~~ help ~~~\n\n" ~ readText(buildPath(resources, "cards/help")) ~ "\n"),
        Mutation("reread-version-after-startup",
            "    private int showTopic(string topic, Memory mem) {",
            "    private int showTopic(string topic, Memory mem) {\n        versionString = resourceVersion(loader);",
            "read", "~~~ read ~~~\n\n    https://oils.pub/release/99.88.77-help-startup-cache/doc/ref/chap-builtin-cmd.html#read\n\n", true)
    ];

    string receipt = "control\tcompile_status\tbaseline_status\tmutant_status\tbaseline_source_sha256\tmutant_source_sha256\tpatch_sha256\tprobe_sha256\texpected_sha256\tbinary_sha256\tresult\n";
    write(buildPath(output, "receipt.tsv"), receipt);
    foreach (mutation; mutations) {
        auto directory = buildPath(output, mutation.name);
        auto copySource = buildPath(directory, "source");
        copySources(source, copySource);
        auto changedPath = buildPath(copySource, "yshd/help.d");
        write(changedPath, replaceOnce(original, mutation.before, mutation.after));
        auto manifest = sourceManifest(copySource);
        write(buildPath(directory, "source.tsv"), manifest);
        auto diff = execute(["/usr/bin/diff", "-u", originalPath, changedPath]);
        if (diff.status != 1) throw new Exception("mutation did not produce an exact diff");
        auto patch = buildPath(directory, "mutation.patch");
        write(patch, diff.output);
        auto script = buildPath(directory, "expectations.grease");
        auto expectedPath = buildPath(directory, "expected.stdout");
        write(script, probe(mutation));
        write(expectedPath, mutation.expected);
        auto controlledRoot = mutation.customVersion ? fileRoot : "";
        auto versionPath = buildPath(fileRoot, "oils-version.txt");
        write(versionPath, initialVersion);
        auto baselineStatus = runLogged([baselineBinary, script, expectedPath, fileRoot],
            buildPath(directory, "baseline"), controlledRoot, true);
        auto expected = "PASS " ~ mutation.name ~ "\n";
        if (baselineStatus != 0 || readText(buildPath(directory, "baseline/stdout")) != expected ||
                readText(buildPath(directory, "baseline/stderr")) != "")
            throw new Exception("final candidate did not pass " ~ mutation.name);
        auto binary = buildPath(directory, "ysh-d-mutant");
        auto compileStatus = runLogged(compilerArguments(compiler, toolchain, root, copySource, binary),
            buildPath(directory, "compile"));
        if (compileStatus != 0) throw new Exception("mutant did not compile: " ~ mutation.name);
        write(versionPath, initialVersion);
        auto mutantStatus = runLogged([binary, script, expectedPath, fileRoot],
            buildPath(directory, "runtime"), controlledRoot, true);
        auto caught = mutantStatus == 1 && readText(buildPath(directory, "runtime/stdout")) != expected;
        receipt ~= mutation.name ~ "\t" ~ to!string(compileStatus) ~ "\t" ~ to!string(baselineStatus) ~
            "\t" ~ to!string(mutantStatus) ~ "\t" ~ hashText(snapshot) ~ "\t" ~ hashText(manifest) ~
            "\t" ~ hash(patch) ~ "\t" ~ hash(script) ~ "\t" ~ hash(expectedPath) ~ "\t" ~ hash(binary) ~
            "\t" ~ (caught ? "PASS" : "FAIL") ~ "\n";
        write(buildPath(output, "receipt.tsv"), receipt);
        if (!caught) throw new Exception("expectations accepted mutant " ~ mutation.name);
        writeln("PASS ", mutation.name, " compile=0 baseline=0 mutant=1");
    }
    if (sourceManifest(source) != snapshot || hash(baselineBinary) != baselineHash)
        throw new Exception("live source or final candidate changed during controls");
    curate(output, lean, mutations);
    return 0;
}
