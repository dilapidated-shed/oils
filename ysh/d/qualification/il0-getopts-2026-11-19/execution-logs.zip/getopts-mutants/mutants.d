module mutants;

import std.algorithm : sort;
import std.array : join;
import std.conv : to;
import std.digest : toHexString;
import std.digest.sha : sha256Of;
import std.file : SpanMode, copy, dirEntries, isDir, mkdirRecurse, read, readText, write;
import std.path : absolutePath, buildPath, dirName, relativePath;
import std.process : execute, spawnProcess, wait;
import std.stdio : File, stderr, writeln;
import std.string : indexOf, replace, toLower;

private string hash(string path) { return sha256Of(read(path)).toHexString.toLower; }
private string hashText(string text) { return sha256Of(text).toHexString.toLower; }

private string[] modules(string source) {
    string[] result;
    foreach (entry; dirEntries(source, SpanMode.depth))
        if (entry.isFile && entry.name.length >= 2 && entry.name[$ - 2 .. $] == ".d") result ~= entry.name;
    sort(result);
    return result;
}

private string sourceManifest(string source) {
    string result;
    foreach (path; modules(source)) result ~= relativePath(path, source) ~ "\t" ~ hash(path) ~ "\n";
    return result;
}

private void copySources(string source, string destination) {
    mkdirRecurse(destination);
    foreach (entry; dirEntries(source, SpanMode.depth)) {
        auto target = buildPath(destination, relativePath(entry.name, source));
        if (entry.isDir) mkdirRecurse(target);
        else {
            mkdirRecurse(dirName(target));
            copy(entry.name, target);
        }
    }
}

private string replaceOnce(string source, string before, string after) {
    auto at = source.indexOf(before);
    if (at < 0 || source[at + before.length .. $].indexOf(before) >= 0)
        throw new Exception("mutation context is absent or ambiguous");
    return source[0 .. at] ~ after ~ source[at + before.length .. $];
}

private int runLogged(string[] argv, string directory) {
    mkdirRecurse(directory);
    auto input = File("/dev/null", "r");
    auto output = File(buildPath(directory, "stdout"), "w");
    auto errors = File(buildPath(directory, "stderr"), "w");
    write(buildPath(directory, "argv.txt"), argv.join("\n") ~ "\n");
    auto status = wait(spawnProcess(argv, input, output, errors));
    write(buildPath(directory, "status"), to!string(status) ~ "\n");
    return status;
}

private struct Mutation {
    string name;
    string before;
    string after;
    string probe;
    bool needsChild;
}

private string[] compilerArguments(string compiler, string toolchain, string root, string source, string binary) {
    auto phobos = buildPath(toolchain, "phobos");
    auto result = [compiler, "-conf=", "-fPIC", "-w", "-I" ~ source,
        "-J" ~ buildPath(root, "stdlib"), "-J" ~ root,
        "-I" ~ buildPath(toolchain, "runtime-dmd/druntime/import"), "-I" ~ phobos,
        buildPath(phobos, "generated/linux/release/64/libphobos2.a"),
        "-defaultlib=", "-debuglib=", "-L-lpthread", "-L-lm", "-L-ldl",
        "-L-Map=" ~ binary ~ ".map"];
    result ~= modules(source);
    result ~= "-of=" ~ binary;
    return result;
}

int main(string[] arguments) {
    if (arguments.length != 5) {
        stderr.writeln("mutants ROOT FINAL_BINARY OUTPUT TOOLCHAIN");
        return 2;
    }
    auto root = absolutePath(arguments[1]);
    auto baselineBinary = absolutePath(arguments[2]);
    auto output = absolutePath(arguments[3]);
    auto toolchain = absolutePath(arguments[4]);
    auto compiler = buildPath(toolchain, "runtime-dmd/generated/linux/release/64/dmd");
    auto source = buildPath(root, "ysh/d/source");
    auto getopts = buildPath(source, "yshd/getopts.d");
    auto original = readText(getopts);
    mkdirRecurse(output);
    auto snapshot = sourceManifest(source);
    write(buildPath(output, "baseline-source.tsv"), snapshot);
    write(buildPath(output, "baseline-getopts.d"), original);
    write(buildPath(output, "baseline-identity.tsv"),
        "kind\tpath\tsha256\ncompiler\t" ~ compiler ~ "\t" ~ hash(compiler) ~
        "\nphobos\t" ~ buildPath(toolchain, "phobos/generated/linux/release/64/libphobos2.a") ~ "\t" ~
        hash(buildPath(toolchain, "phobos/generated/linux/release/64/libphobos2.a")) ~
        "\nbaseline_binary\t" ~ baselineBinary ~ "\t" ~ hash(baselineBinary) ~
        "\nbaseline_source\t" ~ source ~ "\t" ~ hashText(snapshot) ~ "\n");
    auto child = buildPath(output, "stale-child.grease");
    write(child, `trap --add EXIT { echo EXIT }
getopts abc opt -abc
getopts x opt -x
echo resumed
`);
    Mutation[] mutations = [
        Mutation("reset-cluster-cursor",
            "int runGetOpts(string[] words, Memory mem) {",
            "int runGetOpts(string[] words, Memory mem) {\n    mem.getoptsFlagPosition = 1;",
            `set -eu -o pipefail
getopts ab opt -ab
test "$opt" = a
getopts ab opt -ab
test "$opt" = b
test "$OPTIND" = 2
echo 'PASS reset-cluster-cursor'
`),
        Mutation("early-name-validation",
            "    auto status = oneIteration(spec, argv, mem, opterr, selected);",
            "    if (!validName(words[1]))\n        throw new UsageError(\"got invalid variable name \" ~ argumentRepr(words[1]));\n    auto status = oneIteration(spec, argv, mem, opterr, selected);",
            `set -eu -o pipefail
var OPTARG = 'seed'
try { getopts c: broken- -c payload 2>/dev/null }
test "$OPTIND" = 3
test "$OPTARG" = payload
echo 'PASS early-name-validation'
`),
        Mutation("clear-argument-on-double-dash",
            "    if (current == \"--\") {\n        incrementIndex(mem, cachedIndex);",
            "    if (current == \"--\") {\n        mem.setShellVar(\"OPTARG\", Value.str(\"\"));\n        incrementIndex(mem, cachedIndex);",
            `set -eu -o pipefail
var OPTARG = 'seed'
try { getopts a opt -- -a }
test "$OPTARG" = seed
test "$OPTIND" = 2
echo 'PASS clear-argument-on-double-dash'
`),
        Mutation("ordinary-fatal-runs-exit-trap",
            "throw new InterpreterFailure(\"getopts: option byte index out of range\")",
            "throw new FatalRuntimeError(\"getopts: option byte index out of range\")",
            `set -eu -o pipefail
var candidate = ARGV[0]
var child = ARGV[1]
var result = io.captureAll(^( $candidate $child ))
test "$[result.status]" = 1
test "$[len(result.stdout)]" = 0
echo 'PASS ordinary-fatal-runs-exit-trap'
`, true)
    ];

    string receipt = "control\tcompile_status\tbaseline_status\tmutant_status\tbaseline_source_sha256\tmutant_source_sha256\tpatch_sha256\tbinary_sha256\tresult\n";
    foreach (mutation; mutations) {
        auto directory = buildPath(output, mutation.name);
        auto copySource = buildPath(directory, "source");
        copySources(source, copySource);
        auto changed = replaceOnce(original, mutation.before, mutation.after);
        if (mutation.needsChild)
            changed = replaceOnce(changed,
                "import yshd.value : Value, ValueKind, UsageError, InterpreterFailure, kindName;",
                "import yshd.value : Value, ValueKind, UsageError, InterpreterFailure, FatalRuntimeError, kindName;");
        auto changedPath = buildPath(copySource, "yshd/getopts.d");
        write(changedPath, changed);
        auto manifest = sourceManifest(copySource);
        write(buildPath(directory, "source.tsv"), manifest);
        auto diff = execute(["/usr/bin/diff", "-u", getopts, changedPath]);
        if (diff.status != 1) throw new Exception("mutation did not produce an exact diff");
        auto patch = buildPath(directory, "mutation.patch");
        write(patch, diff.output);
        auto probe = buildPath(directory, "expectations.grease");
        write(probe, mutation.probe);
        auto baselineArgs = [baselineBinary, probe];
        if (mutation.needsChild) baselineArgs ~= [baselineBinary, child];
        auto baselineStatus = runLogged(baselineArgs, buildPath(directory, "baseline"));
        auto expected = "PASS " ~ mutation.name ~ "\n";
        if (baselineStatus != 0 || readText(buildPath(directory, "baseline/stdout")) != expected ||
                readText(buildPath(directory, "baseline/stderr")) != "")
            throw new Exception("final candidate did not pass " ~ mutation.name);
        auto binary = buildPath(directory, "ysh-d-mutant");
        auto compileStatus = runLogged(compilerArguments(compiler, toolchain, root, copySource, binary),
            buildPath(directory, "compile"));
        if (compileStatus != 0) throw new Exception("mutant did not compile: " ~ mutation.name);
        auto mutantArgs = [binary, probe];
        if (mutation.needsChild) mutantArgs ~= [binary, child];
        auto mutantStatus = runLogged(mutantArgs, buildPath(directory, "runtime"));
        auto caught = mutantStatus == 1 && readText(buildPath(directory, "runtime/stdout")) != expected;
        receipt ~= mutation.name ~ "\t" ~ to!string(compileStatus) ~ "\t" ~ to!string(baselineStatus) ~
            "\t" ~ to!string(mutantStatus) ~ "\t" ~ hashText(snapshot) ~ "\t" ~ hashText(manifest) ~
            "\t" ~ hash(patch) ~ "\t" ~ hash(binary) ~ "\t" ~ (caught ? "PASS" : "FAIL") ~ "\n";
        write(buildPath(output, "receipt.tsv"), receipt);
        if (!caught) throw new Exception("expectations accepted mutant " ~ mutation.name);
        writeln("PASS ", mutation.name, " compile=0 baseline=0 mutant=1");
    }
    if (sourceManifest(source) != snapshot) throw new Exception("live source changed during controls");
    return 0;
}
